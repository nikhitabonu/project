export interface Movies {
    name: string,
    genre: string,
    language: string,
    image: string,
    visible: boolean
}