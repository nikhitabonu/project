import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hollywood',
  templateUrl: './hollywood.component.html',
  styleUrls: ['./hollywood.component.less']
})
export class HollywoodComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
